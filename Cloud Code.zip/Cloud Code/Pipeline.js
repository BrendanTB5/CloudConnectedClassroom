*
 * Copyright 2010-2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 *  http://aws.amazon.com/apache2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */

//node.js deps

//npm deps

//app deps
const deviceModule = require('aws-iot-device-sdk');
//const cmdLineProcess = require('./lib/cmdline');
const mysql = require('mysql');
const cron = require('node-cron');
const moment = require('moment-timezone');
const math = require('mathjs');
const energyConsumption = 1;


var con;
var currRangeID = 0;
var response;
var tempPoints = [];
var onOrOff = 1;
var p1 = 1, p2 = 1, p3 = 1;
var estimatedTemp;
var costPoints = [0];
var l0 = 0;
const device = deviceModule.device({
      keyPath: "/home/ec2-user/aws-iot-device-sdk-js/certs/private.pem.key",
      certPath:"/home/ec2-user/aws-iot-device-sdk-js/certs/dev-certificate.pem.crt",
      caPath: "/home/ec2-user/aws-iot-device-sdk-js/certs/Amazon-root-CA-1.pem",
      clientId: "Database_Handler",
      host: "a30u0mm8b3ldbd-ats.iot.us-east-2.amazonaws.com",
      port: "8883",
      debug: true

   });
con = mysql.createConnection({
       user        : 'admin',
       password    : 'Tacdzaku9',
       host        : 'mysqltest2.cjlnd7nowtpj.us-east-2.rds.amazonaws.com',
       port        : 3306,
       database    : 'innodb'
});


   //begin module

   function accumulateCostPoints(){
       var tempArray = [];
       if(costPoints.length >= 12){
         tempArray = costPoints.slice(1,12);
         if(onOrOff == 1){
           tempArray[12] = energyConsumption;
         } else {
           tempArray[12] = 0;
         }
         costPoints = tempArray;
       } else {
         if(onOrOff == 1){
           costPoints[costPoints.length] = energyConsumption;
         } else {
           costPoints[costPoints.length] = 0;
         }
       }
   }
   function sumArray(givenArray){
       var len = givenArray.length;
       var i, sum = 0;
       for(i = 0; i < len; i++){
         sum+=givenArray[i];
       }
       return sum;
   }

   function processTest() {
      //
      // The device module exports an MQTT instance, which will attempt
      // to connect to the AWS IoT endpoint configured in the arguments.
      // Once connected, it will emit events which our application can
      // handle.
      //
      //CRONJOB EVERY 15 MINUTES THAT DOES THE COST SAVINGS ALGORITHM
      //CURRENTLY DOESN'T INCORPORATE LIGHT OR NOISE (END GAME GOAL)

      device
         .on('connect', function() {
            console.log('Connected to AWS. Subscribing to everything');
            device.subscribe('gateway/register');
            device.subscribe('gateway/status/#');
            device.subscribe('gateway/+/request');
            device.subscribe('gateway/+/finish');
            device.subscribe('sensor/+/request');
            device.subscribe('sensor/+/alive');
            device.subscribe('sensor/+/data/+');
            device.subscribe('act/+/request');
            device.subscribe('act/+/alive');

         });
      device
         .on('close', function() {
            console.log('close');
         });
      device
         .on('reconnect', function() {
            console.log('reconnect');
         });
      device
         .on('offline', function() {
            console.log('offline');
         });
      device
         .on('error', function(error) {
            console.log(error);
          });
      device
         .on('message', function(topic, payload) {
            console.log('Message:', topic, payload.toString());
            var deconTopic = topic.split("/");
            if(deconTopic[0] == 'gateway'){
                 if(deconTopic[1] == "register"){
                     //CHANGE THIS TO A POOL CONNECTION
                     con.query("SELECT * FROM Gateway WHERE MAC = \'" + payload.toString() + "\'", function (err, result){
                         if (err) throw err;
                         console.log(result);
                         if(result[0].MAC == "04:91:62:0F:09:DE"){
                             //Do nothing
                         } else {
                             var message = result[0].MAC+","+result[0].ID+",";
                             device.publish('gateway/configs',message);
                         }
                     });
                 }

                 else if(deconTopic[1] == "status"){
                     var MACAddr = deconTopic[2];
                     var sql;
                     if(payload.toString() == '1'){
                         sql = "UPDATE Gateway SET alive = '1' WHERE MAC = '"+MACAddr+"'";
                     }else{
                         sql = "UPDATE Gateway SET alive = '0' WHERE MAC = '"+MACAddr+"'";
                     }
                     //CHANGE THIS TO A POOL CONNECTION
                     con.query(sql, function (err, result) {
                       if (err) throw err;
                       console.log(result.affectedRows + " record(s) updated");

                     });
                 }
                 else if(deconTopic[2] == "request"){
                     //CHECK TO MAKE SURE THAT THE PAYLOAD IS A 1
                     var gatewayID = deconTopic[1];
                     if(gatewayID == '4'){
                       con.query("SELECT * FROM Nodes WHERE GatewayID = \'" + gatewayID +"'", function (err, result) {
                       if (err) throw err;
                       console.log(result[0]);
                       var i;
                       var stringS = "S,";
                       var stringA = "A,";
                       var aPresent = false;
                       for(i=0;i<32;i++){
                         try {
                           console.log(result[i]);
                           if(result[i].type == 'S'){
                             stringS = stringS + result[i].ID+",";
                           } else {
                             aPresent = true;
                             stringA = stringA + result[i].ID+",";
                           }
                         } catch(err) {
                           console.log(err);
                           break;
                         }
                       }
                       var message;
                       if(aPresent == true){
                         message = stringS+stringA;
                       }
                       else{
                         message = stringS;
                       }
                       console.log(message);
                       var sentTopic = "gateway/"+gatewayID+"/nodes";
                       device.publish(sentTopic,message);
                       });
                     }

                 }
                 else if(deconTopic[2] == "finish"){
                   var gatewayID = deconTopic[1];
                   var query1 = "SELECT RangeID, Valid FROM Ranges WHERE GatewayID = " + gatewayID + " ORDER BY date DESC, time DESC LIMIT 1";
                   console.log(query1);
                   con.query(query1, function(err, result) {
                     if (err) throw err;
                     try{
                       console.log(result[0]);
                       if(result[0].Valid == '0'){
                         var query2 = "UPDATE Ranges SET Valid = '1'  WHERE RangeID = " + result[0].RangeID;
                         console.log(query2);
                         con.query(query2, function(err1, result1){
                           if (err1) throw err;
                         });
                       }
                     } catch(error){
                     }
                   });
                   currRangeID++;
                 }
               }
              else if(deconTopic[0] == "sensor"){
                if(deconTopic[2] == "request"){
                //CHECK TO SEE IF THE PAYLOAD IS A 1
                  var sensorID = deconTopic[1];
                  //CHANGE THIS TO A POOL CONNECTION
                  //INSERT TRY/CATCH STATEMENT SO THE SYSTEM DOESN'T COMPLETELY DIE
                  if(sensorID != '7'){
                    con.query("SELECT * FROM Nodes WHERE ID = '"+sensorID+"' AND type = 'S'", function (err, result){
                      if (err) throw err;
                      try{
                        console.log(result);
                        var sentTopic = "sensor/"+sensorID+"/SSID";
                        device.publish(sentTopic,result[0].SSID);
                        sentTopic = "sensor/"+sensorID+"/pass";
                        device.publish(sentTopic,result[0].Password);
                      } catch(error) {}
                    });
                  }
                }
                else if(deconTopic[2] == "alive"){
                  var sensorID = deconTopic[1];
                  //PULL THE SENSORID AND MAKE SURE IT IS A SENSOR
                  //FETCH IF THERE IS A SENSOR UPDATE ON MYSQL
                  con.query("SELECT * FROM Nodes WHERE ID = '"+sensorID+"' AND type = 'S'", function (err, result) {
                    var NUID = result[0].NUID;
                    if(result[0].Return != null && result[0].Return != "NULL"){
                      var sentTopic = "sensor/"+sensorID+"/return";
                      device.publish(sentTopic,result[0].Return);
                    }
                    var queryMSG;
                    if(payload.toString() == 1){
                      console.log("ALIVE");
                      queryMSG = "UPDATE Nodes SET alive = '1' WHERE NUID = '"+NUID+"'";
                    } else{
                      console.log("DEAD");
                      queryMSG = "UPDATE Nodes SET alive = '0' WHERE NUID = '"+NUID+"'";
                    }
                    con.query(queryMSG, function(err2,result2) {
                      if(err2) throw err2;
                      console.log(result2);
                    });
                  });
                }
                else if(deconTopic[2] == "data"){
                  var sensorID = deconTopic[1];
                  //CHANGE THIS TO A POOL CONNECTION
                  //INSERT TRY/CATCH STATEMENT SO THE SYSTEM DOESN'T COMPLETELY DIE
                  if(sensorID != '7'){
                    con.query("SELECT * FROM Nodes WHERE ID = '"+sensorID+"' AND type = 'S'", function (err, result){
                    if (err) throw err;
                    console.log(result);
                    var gatewayID = result[0].GatewayID;
                    console.log("Gateway ID:" + gatewayID);
                    var NUID = result[0].NUID;
                    con.query("SELECT * FROM Ranges WHERE GatewayID = "+ gatewayID + " AND Valid = '0'", function (err1, result1) {
                      if (err1) throw err1;
                      try{
                        console.log(result1);
                        var rangeID = result1[0].RangeID;
                        var value = NUID+":"+payload.toString();
                        var sql = "UPDATE RoomRaw SET Node"+sensorID+"MSG = '"+value+"' WHERE RangeID = '"+rangeID.toString()+"'";
                        con.query(sql, function(err2, result2) {
                          if (err2) throw err2;
                          console.log(result2);
                        });
                      } catch(error){
                      }
                    });
                  });
                }
              }
            }
            else if(deconTopic[0]="act"){
                        if(deconTopic[2] == "request"){
                            //CHECK TO SEE IF THE PAYLOAD IS A 1
                            var actID = deconTopic[1];
                            //INSERT A TRY/CATCH SO THE WHOLE SYSTEM DOESN'T DIE
                            //CHANGE TO A POOL CONNECTION
                            con.query("SELECT * FROM Nodes WHERE ID = '"+actID+"' AND type = 'A'", function (err, result) {
                                if (err) throw err;
                                console.log(result);
                                var sentTopic = "act/"+actID+"/SSID";
                                device.publish(sentTopic,result[0].SSID);
                                sentTopic = "act/"+actID+"/pass";
                                device.publish(sentTopic,result[0].Password);
                            });
                        }

                        else if(deconTopic[2] == "alive"){
                            var actID = deconTopic[1];
                            //PULL THE SENSORID AND MAKE SURE IT IS A SENSOR
                            //FETCH IF THERE IS A SENSOR UPDATE ON MYSQL
                            con.query("SELECT * FROM Nodes WHERE ID = '"+actID+"' AND type = 'A'", function (err, result) {
                                    var NUID = result[0].NUID;
                                    console.log(result[0]);
                                    if(result[0].Return != null && result[0].Return != "NULL"){
                                            console.log("Result True");
                                            var sentTopic = "act/"+actID+"/return";
                                            device.publish(sentTopic,result[0].Return);
                                    }
                                  }
                                  console.log(queryMSG);
                                  con.query(queryMSG, function(err2,result2) {
                                          if(err2) throw err2;
                                          console.log(result2);
                                  });
                          });
                      }
                  }
                });

          }
          con.connect(function(err){
                  processTest();
          });
          function getTime(){
              var time = moment().tz("America/Indiana/Indianapolis").format('LTS');
              var info = time.split(" ");
              var hour = parseInt(info[0].split(":")[0],10);
              var min = parseInt(info[0].split(":")[1],10);
              var sec = parseInt(info[0].split(":")[2],10);
              if(info[1] === "PM" && hour != 12){
                hour += 12;
              } else if(info[1] === "AM" && hour === 12){
                hour = 0;
              }
              if(hour < 10){
                hour = "0" + hour;
              }
              if(min < 10){
                min = "0" + min;
              }
              if(sec < 10){
                sec = "0" + sec;
              }
              return hour + ":" + min + ":" +sec;
          }

          function getDate(){
              var date = moment().tz("America/Indiana/Indianapolis").format('L').replace(/\//g, "-");
              var info = date.split("-");
              return info[2] + "-" + info[0] + "-" + info[1];
          }
          function cronHelper(gatewayIDs){
              var ranges = [];
              try{
                var k;
                for(k = 0; k < gatewayIDs.length; k++){
                  console.log("Pos 1");
                  var gatewayID = gatewayIDs[k];
                  console.log("Pos 2");
                  if(gatewayID == '4'){
                      var query1 = "SELECT RangeID, Valid FROM Ranges WHERE GatewayID = " + gatewayID + " ORDER BY date DESC, time DESC LIMIT 1";
                      console.log(query1);
                      con.query(query1, function(err, result) {
                        if (err) throw err;
                        console.log(result[0]);
                        ranges[k] = result[0];
                        var date = getDate();
                        var time = getTime();
                        if(result[0].Valid == '1'){
                          var query2 = "INSERT INTO Ranges VALUES (" + (result[0].RangeID + gatewayIDs.length) + ",'" + date + "','" + time + "'," + gatewayID + ",0)";
                          console.log(query2);
                          con.query(query2, function(err1, result){
                            if (err1) throw err;
                          });
                          var query3 = "INSERT INTO RoomRaw VALUES (" + (result[0].RangeID + gatewayIDs.length) + ",0,0,0,0,0,0,0,0,0,0)";
                          console.log(query3);
                          con.query(query3, function(err1, result){
                            if (err1) throw err;
                          });
                          var sendTopic = "gateway/" + gatewayID + "/timer";
                          console.log(sendTopic);
                          device.publish(sendTopic,"1");
                          console.log("Hello There");
                        }
                      });
                  }
                }
              } catch(err) {
                console.log(err);
              }

          }
          cron.schedule("*/2 * * * *", function(){
              var query = "SELECT ID FROM Gateway WHERE alive = '1'";
              var gatewayIDs = [];
              con.query(query, function(err, result) {
                if (err) throw err;
                var i;
                for(i = 0; i < 3; i++){
                  try{
                    console.log(result);
                    gatewayIDs[i] = result[i].ID;
                    console.log(gatewayIDs[i]);
                  } catch(error){
                    console.log(error);
                    break;
                  }
                }
                console.log("Do you get here?");
                cronHelper(gatewayIDs);
                console.log("AHHHHH");
              });
          });
          function storeDecision(decision, lastDecision, actuatorInfo){
            /*  var decisionID;
              if(lastDecision == 0) {
                decisionID = 1;
              } else {
                decisionID = lastDecision[0]['DUUID'] + 1;
              }
              var dateTime = getDate() + " " + getTime();
              var actID = actuatorInfo[0]['NUID'];
              var values = "(" + decisionID + ",'" + dateTime + "'," + actID + ",'" + decision + "')";
              var query = "INSERT INTO ActuationDecisions VALUES " + values;
              console.log(query);
              con.query(query, function(err, result){
                if(err) throw err;
              });
              onOrOff = !onOrOff;*/
              //Send the Actuator Signal here
          }

          function getLastDecisionNum(decision, actuatorInfo, callback){
            //  var query = "SELECT * FROM ActuationDecisions ORDER BY Performed DESC LIMIT 1";
            // con.query(query, function(err, result){
            //    if(err) throw err;
            //    callback(decision, result, actuatorInfo);
            //  });
          }
          function calculateState(results, currTemp){
             /* var theta = results[0]['theta'];
              var comfTemp = results[0]['Tcomfort'];
              var estWeight, currWeight;
              var estHalf, currHalf;
              var higherTemp = math.max(currTemp, estimatedTemp);
              var tempArray = costPoints.slice(3,12);
              var estCost;
              var sumTemp = sumArray(tempArray);
              var maxCost = 3 * energyConsumption + sumTemp;
              if(onOrOff == 1){
                estCost = maxCost;
              } else {
                estCost = maxCost - 3*energyConsumption;
              }
              var currCost = sumArray(costPoints);
              estHalf = theta*((p1*estCost*estCost + p2*estCost + p3)/(p1*maxCost*maxCost + p2*maxCost + p3));
              currHalf = theta*((p1*currCost*currCost + p2*currCost + p3)/(p1*maxCost*maxCost + p2*maxCost + p3));
              estWeight = estHalf + (1-theta)*(math.pow((estimatedTemp-comfTemp),2)/math.pow((higherTemp-comfTemp),2));
              currWeight = currHalf + (1-theta)*(math.pow(currTemp-comfTemp,2)/math.pow(higherTemp-comfTemp,2));
              if(estWeight > currWeight){
                var decision;
                if(onOrOff == 1) {
                  decision = 'Turned off';
                } else {
                  decision = 'Turned on';
                }
                var query = "SELECT * FROM Nodes WHERE type = 'A' LIMIT 1";//THIS SHOULD IDEALLY TEST IF ALIVE AS WELL
                con.query(query, function(err,result){
                  if(err) throw err;
                  getLastDecisionNum(decision, result, storeDecision);
                });
              }*/
          }
          function estimateTemp(callback){
             /* var sumY = 0, sumX = 0, sumXY = 0, sumX2 = 0;
              var i, a, b;
              console.log("Do you get here?");
              for (i = 0; i < 12; i++){
                sumY += tempPoints[i];
                sumX += i;
                sumXY += i * tempPoints[i];
                sumX2 += i * i;
              }
              a = ((sumY*sumX2) - (sumX*sumXY))/(i*sumX2 - (sumX*sumX));
              b = (i*sumXY - (sumX*sumY))/(i*sumX2-(sumX*sumX));
              estimatedTemp = a + b*15;
              var currTemp = tempPoints[i-1];
              var query = "SELECT * FROM userParams LIMIT 1";
              con.query(query, function(err, result) {
                if (err) throw err;
                callback(result, currTemp);
              });*/
          }
          function tempHelper2(tempNodes, itter, results, callback){
             /* var i;
              var acc = 0;
              for(i = 0; i < 10; i++){
                try{
                  var test = "Node" + tempNodes[i].ID + "MSG";
                  var splitMsg = results[0][test].split(",");
                  acc += parseInt(splitMsg[1]);
                } catch(err) {
                  //console.log("The acc for itter #" + itter + " is " + acc);
                  break;
                }
              }
              tempPoints[itter-1] = acc/i;
              if(tempPoints.length == 12){
                callback(calculateState);
              }*/
          }

          function tempHelper(tempNodes, RangeNum, itter, callback){
            /*  var query = "SELECT * FROM RoomRaw WHERE RangeID = " + RangeNum;
              con.query(query, function(err, result) {
                if (err) throw err;
                tempHelper2(tempNodes, itter, result, callback);
              }); */
          }

          function getTemperatures(tempNodes, RangeIDs, callback){
            //  var i;
            //  for(i = 1; i <= 12; i++){
            //    tempHelper(tempNodes, RangeIDs[12-i].RangeID, i, callback);
            //  }
          }
          function getTempNodes(RangeIDs, callback) {
           /*
           var query = "SELECT * FROM Nodes WHERE method = 'weather' OR method = 'light'";
              con.query(query, function(err, result) {
                if (err) throw err;
                callback(result, RangeIDs, estimateTemp);
              });
          */
          }

          function startSavings(callback){
            /*  var query = "SELECT RangeID FROM Ranges WHERE Valid = 1 ORDER BY date DESC, time DESC LIMIT 12";
              con.query(query, function(err, result) {
                if (err) throw err;
                callback(result, getTemperatures);
              });*/
          }

          //cron.schedule("*/5 * * * *", function(){
              //startSavings(getTempNodes);
          //});
