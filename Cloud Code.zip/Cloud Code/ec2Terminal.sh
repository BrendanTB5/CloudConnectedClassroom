#!/bin/bash
ssh -i "JDS-key-pair-USeast.pem" ec2-user@ec2-18-218-221-199.us-east-2.compute.amazonaws.com
