module.exports = {
    entry: "./entry.js",
    output: {
        path: __dirname,
        filename: "bundle.js"
    },
    node: {
        fs: 'empty',
        tls: 'empty'
    }
};
