#!/bin/bash
mysql -h mysqltest2.cjlnd7nowtpj.us-east-2.rds.amazonaws.com -P 3306 -u admin -p
