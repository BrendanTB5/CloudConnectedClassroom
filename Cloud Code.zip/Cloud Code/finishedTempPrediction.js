
const mysql = require('mysql');
const fetch = require('node-fetch');
const moment = require('moment-timezone');
const math = require('mathjs');
const cron = require('node-cron');
const awsIot = require('aws-iot-device-sdk');
const key = '1a68d7ebd76733e8d4507fea5bdc4646';
const cityID = '4265737';
var connection;
var response;
//var historicalData = new array();


connection = mysql.createConnection({
    user	: 'admin',
    password	: 'Tacdzaku9',
    host	: 'mysqltest2.cjlnd7nowtpj.us-east-2.rds.amazonaws.com',
    port	: 3306,
    database	: 'innodb'
});

function getTime(minOffset){
    var time = moment().tz("America/Indiana/Indianapolis").format('LTS');
    var info = time.split(" ");
    var hour = parseInt(info[0].split(":")[0],10);
    var min = parseInt(info[0].split(":")[1],10) + minOffset;
    var sec = parseInt(info[0].split(":")[2],10);
    if(min > 59){
      hour++;
      min = min - 60;
    }
    if(hour > 12){
      hour = 1;
    }
    if(info[1] === "PM" && hour != 12){
      hour += 12;
    } else if(info[1] === "AM" && hour === 12){
      hour = 0;
    }
    if(hour < 10){
      hour = "0" + hour;
    }
    if(min < 10){
      min = "0" + min;
    }
    if(sec < 10){
      sec = "0" + sec;
    }
    return hour + ":" + min + ":" +sec;
}

function getDate(){
    var date = moment().tz("America/Indiana/Indianapolis").format('L').replace(/\//g, "-");
    var info = date.split("-");
    return info[2] + "-" + info[0] + "-" + info[1];
}


cron.schedule("0 * * * *", function(){
var query = "SELECT * FROM weather_conditions ORDER BY day DESC, stamp DESC LIMIT 12";
connection.query(query,function(err,results){
  if(err) throw err;
  var expY = 0, expX = 0, expXY = 0, expX2 = 0, logY = 0, logX = 0, logXY = 0, logX2 = 0;
  var i, expA, expB, logA, logB;
  var stateCosts = 0;
  for (i = 1; i <= 12; i++){
    expY += math.log(results[12-i]['temp']);
    expX += 5*i;
    expXY += 5*i * math.log(results[12-i]['temp']);
    expX2 += 25*i*i;
    logY += results[12-i]['temp'];
    logX += math.log(5*i);
    logXY += math.log(5*i) * results[12-i]['temp'];
    logX2 += math.log(5*i)*math.log(5*i);
    stateCosts += results[12-i]['stateNum'];
  }
  //console.log(results);
  expA = ((expY*expX2) - (expX*expXY))/(12*expX2 - (expX*expX));
  expB = (12*expXY - (expX*expY))/(12*expX2-(expX*expX));
  logA = ((logY*logX2) - (logX*logXY))/(12*logX2 - (logX*logX));
  logB = (12*logXY - (logX*logY))/(12*logX2-(logX*logX));
  var gofunOut, sanjuupunOut, juugofunOut, yonjuugofunOut, ichijikanOut;
  if(expB > 0){
    gofunOut = logA + logB*math.log(65);
    juugofunOut = logA + logB*math.log(75);
    sanjuupunOut = logA + logB*math.log(90);
    yonjuugofunOut = logA + logB*math.log(105);
    ichijikanOut = logA + logB*math.log(120);
  } else {
    gofunOut = math.exp(expA + expB*65);
    sanjuupunOut = math.exp(expA + expB*90);
    juugofunOut = math.exp(expA + expB*75);
    yonjuugofunOut = math.exp(expA + expB*105);
    ichijikanOut = math.exp(expA + expB*120);
  }
  var  dateTime = getDate() + " " + getTime(0);

  var query1 = "INSERT INTO tempPredictionValidation VALUES ('" + dateTime + "'," + gofunOut + "," + juugofunOut + "," + sanjuupunOut + "," + yonjuugofunOut + "," + ichijikanOut + ")";
  connection.query(query1, function(err1,result){
    if(err1) throw err1;
    console.log("Successful Cronjob");
  });
  //console.log("The a and b are: " + a + ", " + b);
  //console.log(sanjuupunOut);
  //var estS2Temp = 0, estTemp = 0;
  //estS2Temp = maxDiff * (math.exp(estS2TPrime)/(1 + math.exp(estS2TPrime))) + minRoomTemp;
  //estTemp = maxDiff * (math.exp(estTPrime)/(1 + math.exp(estTPrime))) + minRoomTemp;
  //console.log("The estimated Temp for time 1 is: " + estTemp);
  //console.log("The current Temp: " + currTemp);
});
});
//console.log(math.log(math.exp(1)));
//connection.end();
