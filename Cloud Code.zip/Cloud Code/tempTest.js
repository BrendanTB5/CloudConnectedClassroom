const mysql = require('mysql');
const fetch = require('node-fetch');
const moment = require('moment-timezone');
const math = require('mathjs');
const awsIot = require('aws-iot-device-sdk');
const cron = require('node-cron');


const pool = mysql.createPool({
    user	: 'admin',
    password	: 'Tacdzaku9',
    host	: 'mysqltest2.cjlnd7nowtpj.us-east-2.rds.amazonaws.com',
    port	: 3306,
    database	: 'innodb'
});

const device = awsIot.device({
  keyPath: "/home/stichtjd/Documents/SeniorDesign/SeniorDesign/21e89ffb9e-private.pem.key",
  certPath: "/home/stichtjd/Documents/SeniorDesign/SeniorDesign/21e89ffb9e-certificate.pem.crt",
  caPath: "/home/stichtjd/Documents/SeniorDesign/SeniorDesign/rds-ca-2015-root.pem",
  clientId: "Database_Handler_Dalton",
  host: "a30u0mm8b3ldbd-ats.iot.us-east-2.amazonaws.com",
  port: "8883",
  debug: true
});

function readTemp(){
  device
      .on('connect', function() {
         console.log('Connected to AWS. Subscribing to everything');
         device.subscribe('gateway/register');
         device.subscribe('gateway/status/#');
         device.subscribe('gateway/3/request');
         device.subscribe('gateway/3/finish');
         device.subscribe('sensor/7/request');
         device.subscribe('sensor/7/alive');
         device.subscribe('sensor/7/data/+');
      });
  device
      .on('close', function() {
         console.log('close');
      });
  device
      .on('reconnect', function() {
         console.log('reconnect');
      });
  device
      .on('offline', function() {
         console.log('offline');
      });
  device
      .on('error', function(error) {
         console.log(error);
      });
  device
      .on('message', function(topic, payload) {
         console.log('Message:', topic, payload.toString());
         var deconTopic = topic.split("/");
         if(deconTopic[0] == 'gateway'){
           if((deconTopic[1] == "register") && (payload.toString() == "04-91-62-0F-09-DE")){
             pool.getConnection(function(err, connection){
               if (err) throw err;
               connection.query("SELECT * FROM Gateway WHERE MAC = '" + payload.toString() + "'", function(error, results){
                 connection.release();
                 //console.log(results);
                 var message = results[0].MAC+","+results[0].ID+",";
                 device.publish('gateway/configs',message);
               });
             });
           }

          else if(deconTopic[1] == "status"){
             var MACAddr = deconTopic[2];
             var sql;
             if(MACAddr == "04-91-62-0F-09-DE"){
               if(payload.toString() == '1'){
                 sql = "UPDATE Gateway SET alive = '1' WHERE MAC = '" + MACAddr+"'";
               }else{
                 sql = "UPDATE Gateway SET alive = '0' WHERE MAC = '" + MACAddr + "'";
               }
               pool.getConnection(function(err,connection){
                 if (err) throw err;
                 connection.query(sql, function(error, results){
                   connection.release();
                   //console.log(results.affectedRows + "record(s) updated");
                 });
               });
             }
          }

          else if(deconTopic[2] == "request"){
            var gatewayID = deconTopic[1];
            if (gatewayID == '3'){
              pool.getConnection(function(err,connection){
                if (err) throw err;
                connection.query("SELECT * FROM Nodes WHERE GatewayID = '" + gatewayID + "'", function(error, results){
                  connection.release();
                  //console.log(results[0]);
                  var stringS = "S,";
                  try{
                    stringS = stringS + results[0].ID + ",";
                  } catch {
                    console.log("Sensor not setup correctly");
                  }
                  //console.log(stringS);
                  device.publish("gateway/3/nodes",stringS);
                });
              });
            }
          }

          else if(deconTopic[2] == "finish"){
            var query = "SELECT date, time, Valid FROM testTempMeas ORDER BY date DESC, time DESC LIMIT 1";
            //console.log(query);
            if(deconTopic[1] == '3'){
              pool.getConnection(function(err,connection){
                if (err) throw err;
                connection.query(query, function(error,results){
                  connection.release();
                  //console.log(results[0]);
                  if(results[0].Valid == '0'){
                    var sql = "UPDATE testTempMeas SET Valid = 1 WHERE date = '" + results[0].date + "' AND time = '" + results[0].time + "'";
                    console.log(sql);
                    pool.getConnection(function(err1,connection1){
                      if(err1) throw err1;
                      connection1.query(sql,function(error1,results1){
                        connection1.release();
                        //console.log("Gets to end of Finish");
                        if (error1) throw error1;
                      });
                    });
                  }
                });
              });
            }
          }

        }
        else if(deconTopic[0] == "sensor"){
          if(deconTopic[2] == "request"){
            if(payload.toString() == '1' && deconTopic[1] == '7'){
              pool.getConnection(function(err,connection){
                if (err) throw err;
                connection.query("SELECT * FROM Nodes WHERE ID = '7' and type = 'S'", function(error,results){
                  connection.release();
                  //console.log(results);
                  device.publish("sensor/7/SSID", results[0].SSID);
                  device.publish("sensor/7/pass", results[0].Password);
                });
              });
            }
          }

          else if(deconTopic[2] == "alive" && deconTopic[1] == '7'){
            pool.getConnection(function(err,connection){
              if (err) throw err;
              connection.query("SELECT * FROM Nodes WHERE ID = '7' and type = 'S'", function(error,results){
                connection.release();
                if(results[0].result){
                  device.publish("sensor/7/return",results[0].Return);
                }
              });
            });
          }

          else if(deconTopic[2] == "data" && deconTopic[1] == '7'){
            pool.getConnection(function(err,connection){
              if (err) throw err;
              connection.query("SELECT * FROM Nodes WHERE ID = '7' AND type = 'S'", function(error,results){
                connection.release();
                //console.log(results);
                var temp = 32 + 9*parseFloat(payload.toString().split(",")[1])/5;
                var query = "UPDATE testTempMeas SET temp = " + temp + " WHERE Valid = '0'";
                console.log(query);
                pool.getConnection(function(err1,connection1){
                  if (err1) throw err1;
                  connection1.query(query,function(error1,results1){
                    connection1.release();
                    //console.log(results1);
                  });
                });
              });
            });
          }
        }
      });
}

readTemp();

function getTime(minOffset){
    var time = moment().tz("America/Indiana/Indianapolis").format('LTS');
    var info = time.split(" ");
    var hour = parseInt(info[0].split(":")[0],10);
    var min = parseInt(info[0].split(":")[1],10) + minOffset;
    var sec = parseInt(info[0].split(":")[2],10);
    if(min > 59){
      hour++;
      min = min - 60;
    }
    if(hour > 12){
      hour = 1;
    }
    if(info[1] === "PM" && hour != 12){
      hour += 12;
    } else if(info[1] === "AM" && hour === 12){
      hour = 0;
    }
    if(hour < 10){
      hour = "0" + hour;
    }
    if(min < 10){
      min = "0" + min;
    }
    if(sec < 10){
      sec = "0" + sec;
    }
    return hour + ":" + min + ":" +sec;
}

function getDate(){
    var date = moment().tz("America/Indiana/Indianapolis").format('L').replace(/\//g, "-");
    var info = date.split("-");
    return info[2] + "-" + info[0] + "-" + info[1];
}

var stateNum = 0;
const theta = .8;
const comfTemp = 95;
const maxCost = 10;

cron.schedule("* * * * *", function (){
    //This one does the temperature reading and putting it into the database
    //So the message does the actual inserting, this only starts the timer
    var query = "SELECT Valid FROM testTempMeas ORDER BY date DESC, time DESC LIMIT 1";
    //console.log("Started new CronJob");
    pool.getConnection(function(err,connection){
      if (err) throw err;
      connection.query(query, function(error, results){
        connection.release();
        //console.log(results);
        if(results[0].Valid == '1'){
          var query1 = "INSERT INTO testTempMeas VALUES (" + stateNum + ",0,0,'" + getDate() + "','" + getTime(0) + "')";
          //console.log(query1);
          pool.getConnection(function(err1,connection1){
            if (err1) throw err1;
            connection1.query(query1, function(error1, results1){
              connection1.release();
            });
          });
          device.publish("gateway/3/timer","1");
        }
      });
    });
});

cron.schedule("*/5 * * * *", function() {
    var query = "SELECT * FROM testTempMeas WHERE Valid = 1 ORDER BY date DESC, time DESC LIMIT 5";
    pool.getConnection(function(err, connection){
      if(err){
        throw err;
      } else {
          connection.release();

          var numBad = 1;
          var i, a, b;
          var stateCosts = 0;
          for (i = 1; i <= 5; i++){
            if(results[5-i]['temp'] != 0){
              sumY += math.log(results[5-i]['temp']);
              sumX += 5*i;
              sumXY += 5*i * math.log(results[5-i]['temp']);
              sumX2 += 25 * i * i;
              stateCosts += results[5-i]['stateNum'];
            } else {
              numBad++;
            }
          }
          i = i - numBad;
          //Implement Dual Exponential and Logarithmic functionality
          a = ((sumY*sumX2) - (sumX*sumXY))/(i*sumX2 - (sumX*sumX));
          b = (i*sumXY - (sumX*sumY))/(i*sumX2-(sumX*sumX));
          var estS2TPrime = 0, estS0TPrime;
          if(b > 0){
            estS2TPrime = a + 1.7*b*30;
            estS0TPrime = a - b*30;
          } else {
            estS2TPrime = a - 1.7*b*30;
            estS0TPrime = a + b*30;
          }
          var flatLined = 0;
          if(math.abs(b) < .0025){
            console.log(b);
            flatLined = 1;
          }
          var estTPrime = a + b*30;
          var estS2Temp = math.exp(estS2TPrime);
          var estTemp = math.exp(estTPrime);
          var estS0Temp = math.exp(estS0TPrime);
          var currTemp = results[0]['temp'];
          console.log("The estimated Temp: " + estTemp);
          console.log("The current Temp: " + currTemp);
          if(stateNum == 1){
            console.log("The estimated S2 Temp: " + estS2Temp);
            console.log("The estimated S0 Temp: " + estS0Temp);
          }
          var maxTemp = 0;
          if(stateNum == 1){
            maxTemp = math.max(estS2Temp, estTemp, currTemp, estS0Temp);
          } else {
            maxTemp = math.max(estTemp, currTemp);
          }
          var estS2Cost = theta*(1) + (1-theta)*(math.pow((estS2Temp - comfTemp),2)/math.pow((maxTemp - comfTemp),2));
          var estS0Cost = (1-theta)*math.pow((estS0Temp - comfTemp),2)/math.pow((maxTemp-comfTemp),2);
          var estCost = theta*5*stateNum/10 + (1-theta)*(math.pow(estTemp - comfTemp,2)/math.pow(maxTemp - comfTemp,2));
          var currCost = theta*5*stateNum/10 + (1-theta)*(math.pow(currTemp - comfTemp,2)/math.pow(maxTemp - comfTemp,2));
          var minCost = 0;
          if(stateNum == 1){
            minCost = math.min(estS2Cost, estCost, currCost, estS0Cost);
          } else {
            minCost = math.min(estCost, currCost);
          }
          var estStateNum = stateNum;
          var time = getTime(5);
          var date = getDate();
          var values = "(" + estStateNum + "," + estTemp + ",'" + date + "','" + time + "')";
          var query1 = "INSERT INTO testTempEst VALUES " + values;
          pool.getConnection(function(err1, connection1){
            if (err1) throw err1;
            connection1.query(query1, function(error1, results1){
              connection1.release();
              console.log(results1);
            });
          });
          if(stateNum == 1){
            var valuesS2 = "(2," + estS2Temp + ",'" + date + "','" + time + "')";
            var queryS2 = "INSERT INTO testTempEst VALUES " + values;
            pool.getConnection(function(err1,connection1){
              if (err1) throw err1;
              connection1.query(queryS2, function(error1, results1){
                connection1.release();
                console.log(results1);
              });
            });
            var valuesS0 = "(0," + estS0Temp + ",'" + date + "','" + time + "')";
            var queryS0 = "INSERT INTO testTempEst VALUES " + values;
            pool.getConnection(function(err1,connection1){
              if (err1) throw err1;
              connection1.query(queryS0, function(error1, results1){
                connection1.release();
                console.log(results1);
              });
            });
          }
          if(stateNum == 0){
            if(flatLined && (currTemp < comfTemp)){
              console.log("Go to state 1");
              stateNum = 1;
            } else if(minCost == estCost){
              console.log("Stay in state 0");
            } else {
              console.log("Change from State 0 to 1");
              stateNum = 1;
            }
          } else if(stateNum == 1){
            if(minCost == estCost){
              console.log("Stay in state 1");
            } else if(minCost == estS0Cost){
              console.log("Go from state 1 to 0");
              stateNum = 0;
            } else if(minCost == estS2Cost){
              console.log("Go from state 1 to 2");
              stateNum = 2;
            } else {
              if(b > 0){
                console.log("Go from state 1 to 0");
                stateNum = 0;
              } else {
                console.log("Go from state 1 to 2");
                stateNum = 2;
              }
            }
          } else if(stateNum == 2){
            if(flatLined && (currTemp > comfTemp)){
              console.log("Go to state 1");
              stateNum = 1;
            } else if(minCost == estCost){
              console.log("Stay in state 2")
            } else {
              console.log("Change from State 2 to 1");
              stateNum = 1;
            }
          }
        });
      }
    });
});
