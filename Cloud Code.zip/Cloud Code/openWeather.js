
const mysql = require('mysql');
const fetch = require('node-fetch');
const cron = require('node-cron');
const moment = require('moment-timezone');
const key = '1a68d7ebd76733e8d4507fea5bdc4646';
const cityID = '4265737';
var connection;
var response;
var time;
var date;

function getTime(){
  time = moment().tz("America/Indiana/Indianapolis").format('LTS');
  var info = time.split(" ");
  var hour = parseInt(info[0].split(":")[0],10);
  var min = parseInt(info[0].split(":")[1],10);
  var sec = parseInt(info[0].split(":")[2],10);
  if(info[1] === "PM" && hour != 12){
    hour += 12;
  } else if(info[1] === "AM" && hour === 12){
    hour = 0;
  }
  if(hour < 10){
    hour = "0" + hour;
  }
  if(min < 10){
    min = "0" + min;
  }
  if(sec < 10){
    sec = "0" + sec;
  }
  time = hour + ":" + min + ":" + sec;
}

function getDate(){
  date = moment().tz("America/Indiana/Indianapolis").format('L').replace(/\//g, "-");
  var info = date.split("-");
  date = info[2] + "-" + info[0] + "-" + info[1];
}

function sendWeather(data){
  var fahrenheit = ((parseFloat(data.main.temp)-273.15)*1.8)+32;
  var humidity = data.main.humidity;
  getTime();
  getDate();
  var query = "INSERT INTO weather_conditions VALUES (\'" + date + "\', \'" + time + "\', "+ fahrenheit + ", " + humidity + ")";
  console.log(query);
  connection.query(query, function(err,results, fields){
    if(err) throw err;
    console.log(results);
  });
  connection.end(function(error,results){
    console.log("Connection ended");
    return "success";
  });
}

//cron.schedule("*/5 * * * *", function(){
  connection = mysql.createConnection({
      user	: 'admin',
      password	: 'Tacdzaku9',
      host	: 'mysqltest2.cjlnd7nowtpj.us-east-2.rds.amazonaws.com',
      port	: 3306,
      database	: 'innodb'
  });

  //imports.handler = async fuction(event, context) => {
  console.log("Starting query ...");
  connection.connect(function(err){
      if(err) throw err;
      console.log('Connected as id ' + connection.threadId);
  });


  fetch('https://api.openweathermap.org/data/2.5/weather?id=' + cityID + '&appid=' + key)
  .then(function(resp) { return resp.json() })
  .then(function(data) {
    sendWeather(data);
  })
  .catch(function () {

  });
//});
